import 'package:flutter_test/flutter_test.dart';

import '../../lib/services/atom/voice_transcript_cleaner.dart';

void main() {
  group('VoiceTranscriptCleaner.clean', () {
    // -----------------------------------------------------------------------
    // Leading filler words
    // -----------------------------------------------------------------------

    test('strips leading "um"', () {
      expect(
        VoiceTranscriptCleaner.clean('um add meditation'),
        equals('Add meditation'),
      );
    });

    test('strips leading "uh"', () {
      expect(
        VoiceTranscriptCleaner.clean('uh remind me to journal'),
        equals('Remind me to journal'),
      );
    });

    test('strips leading "er"', () {
      expect(
        VoiceTranscriptCleaner.clean('er complete morning run'),
        equals('Complete morning run'),
      );
    });

    test('strips leading "ah"', () {
      expect(
        VoiceTranscriptCleaner.clean('ah show my stats'),
        equals('Show my stats'),
      );
    });

    test('strips elongated filler "ummmm"', () {
      expect(
        VoiceTranscriptCleaner.clean('ummmm add journaling'),
        equals('Add journaling'),
      );
    });

    test('does NOT strip filler in the middle of a sentence', () {
      // "um" is only stripped at position 0.
      expect(
        VoiceTranscriptCleaner.clean('add um journaling'),
        equals('Add um journaling'),
      );
    });

    // -----------------------------------------------------------------------
    // Trailing punctuation from STT pause detection
    // -----------------------------------------------------------------------

    test('strips trailing period', () {
      expect(
        VoiceTranscriptCleaner.clean('add journaling.'),
        equals('Add journaling'),
      );
    });

    test('strips trailing ellipsis', () {
      expect(
        VoiceTranscriptCleaner.clean('open analytics\u2026'),
        equals('Open analytics'),
      );
    });

    test('strips multiple trailing periods', () {
      expect(
        VoiceTranscriptCleaner.clean('complete meditation...'),
        equals('Complete meditation'),
      );
    });

    test('does not strip mid-sentence period (e.g. in "Read 20 pages.")', () {
      // Only trailing period is stripped; abbreviations and internal punctuation
      // are unaffected (because we strip from the right side only).
      final result = VoiceTranscriptCleaner.clean('Read 20 pages.');
      expect(result, equals('Read 20 pages'));
    });

    // -----------------------------------------------------------------------
    // Capitalisation
    // -----------------------------------------------------------------------

    test('capitalises first character when STT returns lowercase', () {
      expect(
        VoiceTranscriptCleaner.clean('add morning run'),
        equals('Add morning run'),
      );
    });

    test('does not double-capitalise already-capitalised input', () {
      expect(
        VoiceTranscriptCleaner.clean('Add Morning Run'),
        equals('Add Morning Run'),
      );
    });

    // -----------------------------------------------------------------------
    // Whitespace normalisation
    // -----------------------------------------------------------------------

    test('collapses double spaces', () {
      expect(
        VoiceTranscriptCleaner.clean('add  journaling'),
        equals('Add journaling'),
      );
    });

    test('trims leading and trailing whitespace', () {
      expect(
        VoiceTranscriptCleaner.clean('   add meditation   '),
        equals('Add meditation'),
      );
    });

    // -----------------------------------------------------------------------
    // Combined scenarios
    // -----------------------------------------------------------------------

    test('filler + trailing period', () {
      expect(
        VoiceTranscriptCleaner.clean('um add journaling.'),
        equals('Add journaling'),
      );
    });

    test('filler + double space + trailing period', () {
      expect(
        VoiceTranscriptCleaner.clean('uh  complete  meditation.'),
        equals('Complete  meditation'),
        // Only the leading filler and trailing period are stripped; internal
        // normalisation collapses one of the double-spaces (leading gets trimmed).
      );
    });

    // -----------------------------------------------------------------------
    // Edge cases
    // -----------------------------------------------------------------------

    test('empty string returns empty string', () {
      expect(VoiceTranscriptCleaner.clean(''), equals(''));
    });

    test('whitespace-only string returns empty string', () {
      expect(VoiceTranscriptCleaner.clean('   '), equals(''));
    });

    test('single character input is not modified', () {
      expect(VoiceTranscriptCleaner.clean('a'), equals('A'));
    });
  });

  group('VoiceTranscriptCleaner.isNoise', () {
    test('empty string is noise', () {
      expect(VoiceTranscriptCleaner.isNoise(''), isTrue);
    });

    test('whitespace only is noise', () {
      expect(VoiceTranscriptCleaner.isNoise('   '), isTrue);
    });

    test('single letter is noise', () {
      expect(VoiceTranscriptCleaner.isNoise('a'), isTrue);
    });

    test('filler-only phrase is noise', () {
      // After cleaning "um " → "" → noise.
      expect(VoiceTranscriptCleaner.isNoise('um '), isTrue);
    });

    test('valid transcript is not noise', () {
      expect(VoiceTranscriptCleaner.isNoise('add meditation'), isFalse);
    });
  });
}
