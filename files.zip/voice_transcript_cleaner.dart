/// Cleans raw speech-to-text transcripts before they are passed to the
/// local intent interpreter or the LLM.
///
/// STT engines frequently emit:
///   • Leading filler words ("um", "uh", "er", "ah")
///   • Spurious punctuation at the end ("add meditation.")
///   • Double spaces from hesitation gaps
///   • All-lowercase output (engine-dependent)
///
/// This cleaner is intentionally conservative — it only removes artefacts
/// that are unambiguously noise. It never removes content words.
class VoiceTranscriptCleaner {
  VoiceTranscriptCleaner._();

  // Filler words that appear ONLY as the first token in a transcript.
  // We do NOT strip mid-sentence fillers; they might be part of a habit name
  // the user is dictating (e.g. "Um the habit" → "The habit").
  static final _leadingFillerRe = RegExp(
    r'^(um+h?|uh+|er+|ah+|hmm+|hm+|mhm+|oh+)\s+',
    caseSensitive: false,
  );

  // STT trailing punctuation artefacts — period / ellipsis from pause detection.
  static final _trailingPunctuationRe = RegExp(r'[.\u2026]+$');

  // Collapse runs of whitespace (tabs, multiple spaces) into single space.
  static final _whitespaceRe = RegExp(r'\s{2,}');

  /// Return a cleaned transcript ready for intent parsing.
  ///
  /// Guarantees:
  ///   • Non-null, non-empty if [raw] contained any word characters.
  ///   • First character is upper-case.
  ///   • No leading/trailing whitespace.
  static String clean(String raw) {
    var s = raw.trim();

    if (s.isEmpty) return s;

    // 1. Strip leading filler word (one pass — don't loop; "um um add X" is
    //    unusual and stripping both would over-clean).
    s = s.replaceFirst(_leadingFillerRe, '');

    // 2. Collapse multiple spaces.
    s = s.replaceAll(_whitespaceRe, ' ').trim();

    // 3. Strip trailing STT punctuation artefacts.
    s = s.replaceFirst(_trailingPunctuationRe, '').trim();

    // 4. Capitalise first character (some engines return all-lowercase).
    if (s.isNotEmpty) {
      s = s[0].toUpperCase() + s.substring(1);
    }

    return s;
  }

  /// Returns true if [raw] appears to be empty or pure noise (all fillers).
  /// The caller should discard the input and wait for the next STT result.
  static bool isNoise(String raw) {
    final cleaned = clean(raw);
    // Fewer than 2 characters after cleaning → treat as noise.
    return cleaned.length < 2;
  }
}
