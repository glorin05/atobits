// ============================================================================
// DROP-IN ADDITIONS for your existing local intent handler
// ============================================================================
//
// How to integrate:
//   1. Add the _analyticsPatterns list and _openAnalyticsResponse constant
//      alongside your other pattern lists.
//   2. Add the open_analytics branch inside your resolveIntent() method
//      (example below).
//   3. Add the fuzzy-match lookup inside your complete/delete/update branches
//      (HabitFuzzyMatcher replaces the current exact-lookup logic).
//   4. Voice path: wrap every incoming STT string in VoiceTranscriptCleaner.clean()
//      before calling resolveIntent().
//
// File references:
//   import 'habit_fuzzy_matcher.dart';
//   import 'voice_transcript_cleaner.dart';
// ============================================================================

// ---------------------------------------------------------------------------
// 1. open_analytics patterns — add to your pattern section
// ---------------------------------------------------------------------------

/// Matches user phrases that should navigate directly to the Analytics screen.
/// Kept broad so both chat ("show my stats") and voice ("open analytics") hit.
const List<String> _analyticsPatterns = [
  r'\banalytics\b',
  r'\bstats?\b',
  r'\bstatistics\b',
  r'\bmy progress\b',
  r'\bshow progress\b',
  r'\bstreaks?\b',
  r'\bhow.{0,10}(am|have) i (done|doing)\b',
  r'\bview (my )?data\b',
  r'\binsights?\b',
];

final _analyticsRe = RegExp(
  _analyticsPatterns.join('|'),
  caseSensitive: false,
);

// ---------------------------------------------------------------------------
// 2. Resolved intent enum value to add (if you use an enum)
// ---------------------------------------------------------------------------
//
// Add to your existing LocalIntent enum:
//   openAnalytics,
//
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// 3. resolveIntent() — add this branch before your fallback
// ---------------------------------------------------------------------------
//
// LocalIntentResult? resolveIntent(String input, List<String> habitTitles) {
//
//   // ... your existing branches ...
//
//   // ── open_analytics ────────────────────────────────────────────────────
//   if (_analyticsRe.hasMatch(input)) {
//     return LocalIntentResult(
//       intent: LocalIntent.openAnalytics,
//       replyText: "Here's your progress so far — opening Analytics now.",
//     );
//   }
//
//   return null; // let the LLM handle it
// }

// ---------------------------------------------------------------------------
// 4. Fuzzy-match lookup for complete / delete / update
// ---------------------------------------------------------------------------
//
// Replace your current exact-match habit lookup with this pattern:
//
// String? _resolveHabitTitle(String userFragment, List<String> existingTitles) {
//   final result = HabitFuzzyMatcher.findWithConfidence(
//     userFragment,
//     existingTitles,
//   );
//   return result?.title; // null → ask user to clarify
// }
//
// For destructive actions (delete), also gate on confidence:
//
// Future<void> _handleDelete(String userFragment, List<String> titles) async {
//   final match = HabitFuzzyMatcher.findWithConfidence(userFragment, titles);
//
//   if (match == null) {
//     atomReply("I couldn't find a habit matching \"$userFragment\". "
//               "Which habit did you mean?");
//     return;
//   }
//
//   // Low-confidence fuzzy match — confirm the title AND the delete action
//   // in a single prompt so the user isn't asked twice.
//   if (match.confidence == MatchConfidence.low) {
//     setPendingDelete(match.title);
//     atomReply("Did you mean \"${match.title}\"? "
//               "Reply yes to delete it, or tell me the habit name.");
//     return;
//   }
//
//   // Exact / high confidence — still confirm the delete (existing safety rule).
//   setPendingDelete(match.title);
//   atomReply("Are you sure you want to delete \"${match.title}\"?");
// }

// ---------------------------------------------------------------------------
// 5. Voice entry point — wrap STT result before processing
// ---------------------------------------------------------------------------
//
// In your voice result callback (e.g. onSpeechResult):
//
// void onSpeechResult(String rawTranscript) {
//   final clean = VoiceTranscriptCleaner.clean(rawTranscript);
//   if (VoiceTranscriptCleaner.isNoise(clean)) return; // discard; wait for more
//   processUserInput(clean); // your existing pipeline
// }
