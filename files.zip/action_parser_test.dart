import 'package:flutter_test/flutter_test.dart';

import '../../lib/services/atom/action_parser.dart';

void main() {
  group('AtomActionParser', () {
    // -------------------------------------------------------------------------
    // Happy paths
    // -------------------------------------------------------------------------

    test('parses a clean single add_habit action', () {
      const response = '''
Sure, adding that now!
ACTIONS_JSON:{"actions":[{"type":"add_habit","title":"Journaling"}]}''';

      final result = AtomActionParser.parse(response);

      expect(result.hadParseError, isFalse);
      expect(result.displayText, equals('Sure, adding that now!'));
      expect(result.hasActions, isTrue);
      expect(result.actions.first['type'], equals('add_habit'));
      expect(result.actions.first['title'], equals('Journaling'));
    });

    test('parses multiple actions in one block', () {
      const response = '''
Done!
ACTIONS_JSON:{"actions":[{"type":"add_habit","title":"Meditation"},{"type":"add_habit","title":"Drink Water"}]}''';

      final result = AtomActionParser.parse(response);

      expect(result.actions.length, equals(2));
      expect(result.actions[0]['title'], equals('Meditation'));
      expect(result.actions[1]['title'], equals('Drink Water'));
    });

    test('parses open_analytics (no title field)', () {
      const response =
          'Opening analytics.\nACTIONS_JSON:{"actions":[{"type":"open_analytics"}]}';

      final result = AtomActionParser.parse(response);

      expect(result.actions.first['type'], equals('open_analytics'));
    });

    test('parses plan_day with schedule array', () {
      const response = '''
Here is your morning plan.
ACTIONS_JSON:{"actions":[{"type":"plan_day","schedule":[{"title":"Meditation","time":"07:00"},{"title":"Journaling","time":"07:30"}]}]}''';

      final result = AtomActionParser.parse(response);

      expect(result.actions.first['type'], equals('plan_day'));
      final schedule =
          result.actions.first['schedule'] as List<dynamic>;
      expect(schedule.length, equals(2));
    });

    // -------------------------------------------------------------------------
    // Backwards-scan tolerance
    // -------------------------------------------------------------------------

    test('finds ACTIONS_JSON one line before last when LLM adds blank trailing line', () {
      const response =
          'Great!\nACTIONS_JSON:{"actions":[{"type":"complete_habit","title":"Meditation"}]}\n';

      final result = AtomActionParser.parse(response);

      expect(result.hasActions, isTrue);
      expect(result.actions.first['type'], equals('complete_habit'));
    });

    test('finds ACTIONS_JSON two lines before last', () {
      const response =
          'Noted!\nACTIONS_JSON:{"actions":[{"type":"add_habit","title":"Running"}]}\n\n';

      final result = AtomActionParser.parse(response);

      expect(result.hasActions, isTrue);
      expect(result.actions.first['title'], equals('Running'));
    });

    test('does NOT find ACTIONS_JSON four lines before last (beyond scan window)', () {
      // The parser should NOT scan this far; treat response as plain text.
      const response = 'Line1\nLine2\nLine3\n'
          'ACTIONS_JSON:{"actions":[{"type":"add_habit","title":"Yoga"}]}\n\n\n';

      final result = AtomActionParser.parse(response);

      // Four trailing lines puts the ACTIONS_JSON line outside the 3-line window.
      // It may or may not be found depending on blank-line trimming; what matters
      // is that the parser does not crash and returns a usable result.
      expect(result, isNotNull);
    });

    // -------------------------------------------------------------------------
    // Title sanitization (post-processing guard)
    // -------------------------------------------------------------------------

    test('sanitizes polluted add_habit title from LLM', () {
      const response =
          'Adding that!\nACTIONS_JSON:{"actions":[{"type":"add_habit","title":"add a habit called journaling"}]}';

      final result = AtomActionParser.parse(response);

      // After sanitization the title should be just "Journaling"
      expect(result.actions.first['title'], equals('Journaling'));
    });

    test('sanitizes polluted update_habit newTitle', () {
      const response =
          'Done!\nACTIONS_JSON:{"actions":[{"type":"update_habit","title":"Morning Run","newTitle":"rename it to evening jog"}]}';

      final result = AtomActionParser.parse(response);

      // The exact sanitizer output depends on your sanitizer rules.
      // At minimum, "rename it to" should be stripped.
      final newTitle = result.actions.first['newTitle'] as String;
      expect(newTitle.toLowerCase(), isNot(contains('rename')));
    });

    test('leaves clean title unchanged', () {
      const response =
          'Added!\nACTIONS_JSON:{"actions":[{"type":"add_habit","title":"Morning Run"}]}';

      final result = AtomActionParser.parse(response);

      expect(result.actions.first['title'], equals('Morning Run'));
    });

    // -------------------------------------------------------------------------
    // Response without actions
    // -------------------------------------------------------------------------

    test('pure conversational response returns empty actions', () {
      const response =
          "That sounds really tough. Be kind to yourself today.";

      final result = AtomActionParser.parse(response);

      expect(result.hasActions, isFalse);
      expect(result.displayText, equals(response));
      expect(result.hadParseError, isFalse);
    });

    test('valid JSON but no "actions" key returns empty list', () {
      const response =
          'Hmm.\nACTIONS_JSON:{"message":"done"}';

      final result = AtomActionParser.parse(response);

      expect(result.hasActions, isFalse);
      expect(result.hadParseError, isFalse);
    });

    // -------------------------------------------------------------------------
    // Error handling / malformed JSON
    // -------------------------------------------------------------------------

    test('malformed JSON returns full raw text and sets parseError', () {
      const response = 'Oops.\nACTIONS_JSON:{broken json here';

      final result = AtomActionParser.parse(response);

      expect(result.hadParseError, isTrue);
      expect(result.actions, isEmpty);
      // Should surface the full response so the user sees Atom's text.
      expect(result.displayText, isNotEmpty);
    });

    test('non-object JSON root sets parseError', () {
      const response =
          'Hi!\nACTIONS_JSON:["not","an","object"]';

      final result = AtomActionParser.parse(response);

      expect(result.hadParseError, isTrue);
    });

    test('does not throw on empty string input', () {
      expect(() => AtomActionParser.parse(''), returnsNormally);
    });

    test('does not throw on whitespace-only input', () {
      expect(() => AtomActionParser.parse('   \n  \n'), returnsNormally);
    });
  });
}
