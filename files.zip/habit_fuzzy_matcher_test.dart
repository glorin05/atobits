import 'package:flutter_test/flutter_test.dart';

import '../../lib/services/atom/habit_fuzzy_matcher.dart';

void main() {
  // Shared test corpus matching typical user habit lists.
  const habits = [
    'Morning Run',
    'Journaling',
    'Meditation',
    'Drink Water',
    'Read 20 Pages',
    'HIIT Workout',
    'Evening Walk',
    'Cold Shower',
  ];

  group('HabitFuzzyMatcher.findBestMatch', () {
    // -----------------------------------------------------------------------
    // Exact / case-insensitive matches
    // -----------------------------------------------------------------------

    test('exact match (same case)', () {
      expect(
        HabitFuzzyMatcher.findBestMatch('Morning Run', habits),
        equals('Morning Run'),
      );
    });

    test('exact match (different case)', () {
      expect(
        HabitFuzzyMatcher.findBestMatch('morning run', habits),
        equals('Morning Run'),
      );
    });

    test('exact match (all caps)', () {
      expect(
        HabitFuzzyMatcher.findBestMatch('JOURNALING', habits),
        equals('Journaling'),
      );
    });

    // -----------------------------------------------------------------------
    // Normalised exact (articles stripped)
    // -----------------------------------------------------------------------

    test('strips leading article "my" before matching', () {
      expect(
        HabitFuzzyMatcher.findBestMatch('my meditation', habits),
        equals('Meditation'),
      );
    });

    test('strips leading article "the" before matching', () {
      expect(
        HabitFuzzyMatcher.findBestMatch('the evening walk', habits),
        equals('Evening Walk'),
      );
    });

    // -----------------------------------------------------------------------
    // Contains matches
    // -----------------------------------------------------------------------

    test('query is substring of title', () {
      // "run" ⊂ "Morning Run"
      expect(
        HabitFuzzyMatcher.findBestMatch('run', habits),
        equals('Morning Run'),
      );
    });

    test('title is substring of query', () {
      // "Journaling" ⊂ "do some journaling today"
      expect(
        HabitFuzzyMatcher.findBestMatch('do some journaling today', habits),
        equals('Journaling'),
      );
    });

    // -----------------------------------------------------------------------
    // Word-overlap
    // -----------------------------------------------------------------------

    test('partial word overlap: "morning jog" → "Morning Run"', () {
      // "morning" overlaps; "jog" and "run" don't — overlap = 1/3 ≈ 0.33.
      // Depending on threshold this may or may not match via overlap;
      // Levenshtein fallback should still find it.
      final match = HabitFuzzyMatcher.findBestMatch('morning jog', habits);
      expect(match, equals('Morning Run'));
    });

    test('high word overlap: "read pages" → "Read 20 Pages"', () {
      expect(
        HabitFuzzyMatcher.findBestMatch('read pages', habits),
        equals('Read 20 Pages'),
      );
    });

    // -----------------------------------------------------------------------
    // Levenshtein / typo tolerance
    // -----------------------------------------------------------------------

    test('one-char typo: "Meditaton" → "Meditation"', () {
      expect(
        HabitFuzzyMatcher.findBestMatch('Meditaton', habits),
        equals('Meditation'),
      );
    });

    test('two-char typo: "Journalingg" → "Journaling"', () {
      expect(
        HabitFuzzyMatcher.findBestMatch('Journalingg', habits),
        equals('Journaling'),
      );
    });

    test('transposition typo: "Mditation" → "Meditation"', () {
      expect(
        HabitFuzzyMatcher.findBestMatch('Mditation', habits),
        equals('Meditation'),
      );
    });

    // -----------------------------------------------------------------------
    // No match
    // -----------------------------------------------------------------------

    test('returns null when nothing is close enough', () {
      expect(
        HabitFuzzyMatcher.findBestMatch('Cooking', habits),
        isNull,
      );
    });

    test('returns null for empty query', () {
      expect(HabitFuzzyMatcher.findBestMatch('', habits), isNull);
    });

    test('returns null for empty habit list', () {
      expect(HabitFuzzyMatcher.findBestMatch('Meditation', []), isNull);
    });

    // -----------------------------------------------------------------------
    // Acronym / special format
    // -----------------------------------------------------------------------

    test('acronym match: "hiit" → "HIIT Workout"', () {
      expect(
        HabitFuzzyMatcher.findBestMatch('hiit', habits),
        equals('HIIT Workout'),
      );
    });
  });

  // -------------------------------------------------------------------------
  group('HabitFuzzyMatcher.findWithConfidence', () {
    test('exact match returns MatchConfidence.exact', () {
      final result = HabitFuzzyMatcher.findWithConfidence('Meditation', habits);
      expect(result, isNotNull);
      expect(result!.title, equals('Meditation'));
      expect(result.confidence, equals(MatchConfidence.exact));
    });

    test('contains match returns MatchConfidence.high', () {
      final result = HabitFuzzyMatcher.findWithConfidence('run', habits);
      expect(result, isNotNull);
      expect(result!.confidence, equals(MatchConfidence.high));
    });

    test('2-char Levenshtein returns MatchConfidence.low', () {
      // "Coldshwr" is distance 2–3 from "Cold Shower"
      final result =
          HabitFuzzyMatcher.findWithConfidence('Coldshwr', habits);
      if (result != null) {
        // If matched, confidence must not be exact.
        expect(result.confidence, isNot(MatchConfidence.exact));
      }
    });

    test('no match returns null', () {
      final result =
          HabitFuzzyMatcher.findWithConfidence('Skydiving', habits);
      expect(result, isNull);
    });
  });

  // -------------------------------------------------------------------------
  group('HabitFuzzyMatcher.levenshtein', () {
    test('identical strings → 0', () {
      expect(HabitFuzzyMatcher.levenshtein('abc', 'abc'), equals(0));
    });

    test('empty vs non-empty → length of non-empty', () {
      expect(HabitFuzzyMatcher.levenshtein('', 'abc'), equals(3));
      expect(HabitFuzzyMatcher.levenshtein('abc', ''), equals(3));
    });

    test('single insertion', () {
      expect(HabitFuzzyMatcher.levenshtein('ab', 'abc'), equals(1));
    });

    test('single deletion', () {
      expect(HabitFuzzyMatcher.levenshtein('abc', 'ac'), equals(1));
    });

    test('single substitution', () {
      expect(HabitFuzzyMatcher.levenshtein('cat', 'bat'), equals(1));
    });

    test('transposition (not adjacent swap — standard Levenshtein = 2)', () {
      // Levenshtein (not Damerau) counts transposition as 2 ops.
      expect(HabitFuzzyMatcher.levenshtein('ab', 'ba'), equals(2));
    });

    test('longer strings', () {
      expect(
        HabitFuzzyMatcher.levenshtein('meditation', 'mediation'),
        equals(1),
      );
    });
  });
}
