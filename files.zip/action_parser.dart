import 'dart:convert';

import 'package:flutter/foundation.dart';

import 'habit_title_sanitizer.dart';

/// Parses the ACTIONS_JSON automation block from a raw LLM response.
///
/// Handles the known LLM failure modes:
///   • Extra trailing newlines / whitespace after the action line
///   • ACTIONS_JSON appearing 1–3 lines before the actual last line
///   • Malformed JSON → graceful fallback to display-text-only result
///   • Title pollution → post-sanitizes add_habit.title and update_habit.newTitle
///
/// Usage:
///   final result = AtomActionParser.parse(llmResponseText);
///   showMessageToUser(result.displayText);
///   for (final action in result.actions) { executeAction(action); }
class AtomActionParser {
  AtomActionParser._();

  static const _prefix = 'ACTIONS_JSON:';

  /// Max number of trailing lines to scan backwards when looking for the
  /// ACTIONS_JSON line. The LLM occasionally emits a stray blank line after
  /// the block; 3 gives us headroom without false-positives.
  static const _maxScanLines = 3;

  /// Parse [rawResponse] into a display text and a list of typed action maps.
  ///
  /// Never throws — parsing failures are captured in [AtomParseResult.parseError].
  static AtomParseResult parse(String rawResponse) {
    // Normalise line endings; trim trailing whitespace from each line.
    final lines = rawResponse
        .replaceAll('\r\n', '\n')
        .split('\n')
        .map((l) => l.trimRight())
        .toList();

    // Remove purely empty trailing lines before scanning.
    while (lines.isNotEmpty && lines.last.trim().isEmpty) {
      lines.removeLast();
    }

    String? actionLine;
    int foundAtIndex = -1;

    // Scan backwards from last line up to _maxScanLines.
    final scanStart = lines.length - 1;
    final scanEnd = (lines.length - _maxScanLines).clamp(0, lines.length - 1);

    for (int i = scanStart; i >= scanEnd; i--) {
      if (lines[i].trimLeft().startsWith(_prefix)) {
        actionLine = lines[i].trimLeft();
        foundAtIndex = i;
        break;
      }
    }

    // Everything before the action line is shown to the user.
    final displayLines =
        foundAtIndex >= 0 ? lines.sublist(0, foundAtIndex) : lines;
    final displayText = displayLines.join('\n').trim();

    if (actionLine == null) {
      return AtomParseResult(displayText: displayText, actions: const []);
    }

    final jsonStr = actionLine.substring(_prefix.length).trim();

    try {
      final decoded = jsonDecode(jsonStr);
      if (decoded is! Map<String, dynamic>) {
        throw const FormatException('Top-level value must be a JSON object');
      }

      final rawList = decoded['actions'];
      if (rawList == null) {
        // Valid JSON but no "actions" key — treat as intent-free response.
        return AtomParseResult(displayText: displayText, actions: const []);
      }
      if (rawList is! List) {
        throw const FormatException('"actions" must be a JSON array');
      }

      final actions = <Map<String, dynamic>>[];
      for (final raw in rawList) {
        if (raw is! Map) continue;
        actions.add(_sanitizeAction(Map<String, dynamic>.from(raw)));
      }

      return AtomParseResult(displayText: displayText, actions: actions);
    } catch (e, st) {
      debugPrint('AtomActionParser: JSON parse failed — $e\n$st');
      // Surface the full response text so nothing is swallowed.
      return AtomParseResult(
        displayText: rawResponse.trim(),
        actions: const [],
        parseError: e.toString(),
      );
    }
  }

  // ---------------------------------------------------------------------------
  // Private helpers
  // ---------------------------------------------------------------------------

  /// Apply the shared sanitizer to any titles the LLM might have polluted.
  /// Mutates a copy; the original map is not touched.
  static Map<String, dynamic> _sanitizeAction(Map<String, dynamic> action) {
    final type = action['type'] as String?;

    if (type == 'add_habit') {
      action['title'] = _guardTitle(action['title'], 'add_habit.title');
    }

    if (type == 'update_habit') {
      if (action.containsKey('newTitle')) {
        action['newTitle'] =
            _guardTitle(action['newTitle'], 'update_habit.newTitle');
      }
    }

    return action;
  }

  /// Run [HabitTitleSanitizer.sanitize]; if it throws, log and return the
  /// raw value — the executor layer will do a second guard check.
  static String _guardTitle(dynamic raw, String field) {
    if (raw is! String) return '';
    try {
      return HabitTitleSanitizer.sanitize(raw);
    } on HabitTitleParseException catch (e) {
      debugPrint('AtomActionParser: sanitizer rejected $field="$raw" — $e');
      return raw; // keep raw; executor must validate before persisting
    }
  }
}

// =============================================================================
// Result type
// =============================================================================

/// The structured result of parsing an LLM response.
@immutable
class AtomParseResult {
  /// The portion of the response shown to the user (stripped of ACTIONS_JSON).
  final String displayText;

  /// Validated, post-sanitized action maps ready for the executor.
  final List<Map<String, dynamic>> actions;

  /// Non-null when JSON parsing failed; the executor should not run actions.
  final String? parseError;

  const AtomParseResult({
    required this.displayText,
    required this.actions,
    this.parseError,
  });

  bool get hasActions => actions.isNotEmpty;
  bool get hadParseError => parseError != null;

  @override
  String toString() =>
      'AtomParseResult(actions: ${actions.length}, error: $parseError)';
}
